<?php 
error_reporting(EP_ALL);//E_ALL
ini_set("display_errors",1); //1

/* load theme js and css
–––––––––––––––––––––––––––––––––––––––––––––––––------– */
function vtn_child_scripts() {
	// enqueue parent styles
	wp_enqueue_style('vtn-starter-css', get_template_directory_uri() .'/style.css', array() );
	// bootstrap full
	// wp_enqueue_style( 'vtn-bootstrap-style-full', get_stylesheet_directory_uri() . '/assets/bootstrap/css/bootstrap.min.css' );
	// bootstrap only grid
	wp_enqueue_style( 'vtn-bootstrap-style-grid', get_stylesheet_directory_uri() . '/assets/bootstrap/css/bootstrap-grid.min.css' );
	// fontawesome
	wp_enqueue_style( 'vtn-fontawesome-style', get_stylesheet_directory_uri() . '/assets/fontawesome/css/all.min.css' );
	// custom
	wp_enqueue_style( 'vtn-child-style', get_stylesheet_directory_uri() . '/assets/css/vtn-custom.css' );
	
	// bootstrap with popper
	// wp_enqueue_script( 'vtn-bootstrap-popper-js' , get_stylesheet_directory_uri() . '/assets/bootstrap/js/bootstrap.bundle.min.js', array('jquery') );
	// bootstrap js
	wp_enqueue_script( 'vtn-bootstrap-js' , get_stylesheet_directory_uri() . '/assets/bootstrap/js/bootstrap.min.js', array('jquery') );
	// theme JS
	wp_enqueue_script( 'vtn-child-js', get_stylesheet_directory_uri() . '/assets/js/vtn-custom.js', array('child-js'), true );
}
add_action( 'wp_enqueue_scripts', 'vtn_child_scripts' );

echo '<i class="fas fa-ship"></i>';